#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <epicsTypes.h>
#include <epicsTime.h>
#include <epicsMutex.h>
#include <epicsEvent.h>
#include <iocsh.h>
#include <errlog.h>
#include <epicsExport.h>
#include <epicsThread.h>
#include <epicsString.h>
#include <epicsTimer.h>
#include <epicsExit.h>
#include <epicsMutex.h>
#include <cantProceed.h>

#include <asynDriver.h>
#include <asynInt32.h>
#include <asynFloat64.h>
#include <asynInt32Array.h>
#include <asynFloat64Array.h>
#include <asynDrvUser.h>
#include <asynPortClient.h>

#include "drvMks937b.h"

static const char *driverName = "drvMks937b";

drvMks937b::drvMks937b(const char *myPortName, const char *commPortName, const int nDevAddr, const double dbTimeout, const int nDevIdx)
	: asynPortDriver(myPortName,
			1, /* maxAddr */
			NUM_MKS937B_PARAMS,
			asynInt32Mask | asynFloat64Mask | asynFloat64ArrayMask | asynOctetMask | asynEnumMask | asynDrvUserMask,
			asynInt32Mask | asynFloat64Mask | asynFloat64ArrayMask | asynOctetMask | asynEnumMask,
			0,
			1,
			0,
			0),
	m_bRun(false),m_dbCommDelay(1),m_pComm(NULL),m_nDevAddr(nDevAddr),m_dbTimeout(dbTimeout)
{
	asynStatus status;
	const char *functionName = "drvMks937b";

	createParam(P_mks937bIsAliveString,			asynParamInt32,					&P_mks937bIsAlive);
	createParam(P_mks937bPRCh1String,			asynParamFloat64,                &P_mks937bPR[0]);
	createParam(P_mks937bPRCh2String,			asynParamFloat64,                &P_mks937bPR[1]);
	createParam(P_mks937bPRCh3String,			asynParamFloat64,                &P_mks937bPR[2]);
	createParam(P_mks937bPRCh4String,			asynParamFloat64,                &P_mks937bPR[3]);
	createParam(P_mks937bPRCh5String,			asynParamFloat64,                &P_mks937bPR[4]);
	createParam(P_mks937bPRCh6String,			asynParamFloat64,                &P_mks937bPR[5]);
	
	createParam(P_mks937bPCCh1String,			asynParamFloat64,                &P_mks937bPC[0]);
	createParam(P_mks937bPCCh2String,			asynParamFloat64,                &P_mks937bPC[1]);
	
	createParam(P_mks937bSPCh1String,			asynParamFloat64,                &P_mks937bSP[0]);
	createParam(P_mks937bSPCh2String,			asynParamFloat64,                &P_mks937bSP[1]);
	createParam(P_mks937bSPCh3String,			asynParamFloat64,                &P_mks937bSP[2]);
	createParam(P_mks937bSPCh4String,			asynParamFloat64,                &P_mks937bSP[3]);
	createParam(P_mks937bSPCh5String,			asynParamFloat64,                &P_mks937bSP[4]);
	createParam(P_mks937bSPCh6String,			asynParamFloat64,                &P_mks937bSP[5]);
	createParam(P_mks937bSPCh7String,			asynParamFloat64,                &P_mks937bSP[6]);
	createParam(P_mks937bSPCh8String,			asynParamFloat64,                &P_mks937bSP[7]);
	createParam(P_mks937bSPCh9String,			asynParamFloat64,                &P_mks937bSP[8]);
	createParam(P_mks937bSPCh10String,			asynParamFloat64,                &P_mks937bSP[9]);
	createParam(P_mks937bSPCh11String,			asynParamFloat64,                &P_mks937bSP[10]);
	createParam(P_mks937bSPCh12String,			asynParamFloat64,                &P_mks937bSP[11]);

	createParam(P_mks937bSHCh1String,			asynParamFloat64,                &P_mks937bSH[0]);
	createParam(P_mks937bSHCh2String,			asynParamFloat64,                &P_mks937bSH[1]);
	createParam(P_mks937bSHCh3String,			asynParamFloat64,                &P_mks937bSH[2]);
	createParam(P_mks937bSHCh4String,			asynParamFloat64,                &P_mks937bSH[3]);
	createParam(P_mks937bSHCh5String,			asynParamFloat64,                &P_mks937bSH[4]);
	createParam(P_mks937bSHCh6String,			asynParamFloat64,                &P_mks937bSH[5]);
	createParam(P_mks937bSHCh7String,			asynParamFloat64,                &P_mks937bSH[6]);
	createParam(P_mks937bSHCh8String,			asynParamFloat64,                &P_mks937bSH[7]);
	createParam(P_mks937bSHCh9String,			asynParamFloat64,                &P_mks937bSH[8]);
	createParam(P_mks937bSHCh10String,			asynParamFloat64,                &P_mks937bSH[9]);
	createParam(P_mks937bSHCh11String,			asynParamFloat64,                &P_mks937bSH[10]);
	createParam(P_mks937bSHCh12String,			asynParamFloat64,                &P_mks937bSH[11]);

	createParam(P_mks937bSDCh1String,			asynParamInt32,                  &P_mks937bSD[0]);
	createParam(P_mks937bSDCh2String,			asynParamInt32,                  &P_mks937bSD[1]);
	createParam(P_mks937bSDCh3String,			asynParamInt32,                  &P_mks937bSD[2]);
	createParam(P_mks937bSDCh4String,			asynParamInt32,                  &P_mks937bSD[3]);
	createParam(P_mks937bSDCh5String,			asynParamInt32,                  &P_mks937bSD[4]);
	createParam(P_mks937bSDCh6String,			asynParamInt32,                  &P_mks937bSD[5]);
	createParam(P_mks937bSDCh7String,			asynParamInt32,                  &P_mks937bSD[6]);
	createParam(P_mks937bSDCh8String,			asynParamInt32,                  &P_mks937bSD[7]);
	createParam(P_mks937bSDCh9String,			asynParamInt32,                  &P_mks937bSD[8]);
	createParam(P_mks937bSDCh10String,			asynParamInt32,                  &P_mks937bSD[9]);
	createParam(P_mks937bSDCh11String,			asynParamInt32,                  &P_mks937bSD[10]);
	createParam(P_mks937bSDCh12String,			asynParamInt32,                  &P_mks937bSD[11]);

	createParam(P_mks937bENCh1String,			asynParamInt32,                  &P_mks937bEN[0]);
	createParam(P_mks937bENCh2String,			asynParamInt32,                  &P_mks937bEN[1]);
	createParam(P_mks937bENCh3String,			asynParamInt32,                  &P_mks937bEN[2]);
	createParam(P_mks937bENCh4String,			asynParamInt32,                  &P_mks937bEN[3]);
	createParam(P_mks937bENCh5String,			asynParamInt32,                  &P_mks937bEN[4]);
	createParam(P_mks937bENCh6String,			asynParamInt32,                  &P_mks937bEN[5]);
	createParam(P_mks937bENCh7String,			asynParamInt32,                  &P_mks937bEN[6]);
	createParam(P_mks937bENCh8String,			asynParamInt32,                  &P_mks937bEN[7]);
	createParam(P_mks937bENCh9String,			asynParamInt32,                  &P_mks937bEN[8]);
	createParam(P_mks937bENCh10String,			asynParamInt32,                  &P_mks937bEN[9]);
	createParam(P_mks937bENCh11String,			asynParamInt32,                  &P_mks937bEN[10]);
	createParam(P_mks937bENCh12String,			asynParamInt32,                  &P_mks937bEN[11]);

	createParam(P_mks937bSSCh1String,			asynParamInt32,                  &P_mks937bSS[0]);
	createParam(P_mks937bSSCh2String,			asynParamInt32,                  &P_mks937bSS[1]);
	createParam(P_mks937bSSCh3String,			asynParamInt32,                  &P_mks937bSS[2]);
	createParam(P_mks937bSSCh4String,			asynParamInt32,                  &P_mks937bSS[3]);
	createParam(P_mks937bSSCh5String,			asynParamInt32,                  &P_mks937bSS[4]);
	createParam(P_mks937bSSCh6String,			asynParamInt32,                  &P_mks937bSS[5]);
	createParam(P_mks937bSSCh7String,			asynParamInt32,                  &P_mks937bSS[6]);
	createParam(P_mks937bSSCh8String,			asynParamInt32,                  &P_mks937bSS[7]);
	createParam(P_mks937bSSCh9String,			asynParamInt32,                  &P_mks937bSS[8]);
	createParam(P_mks937bSSCh10String,			asynParamInt32,                  &P_mks937bSS[9]);
	createParam(P_mks937bSSCh11String,			asynParamInt32,                  &P_mks937bSS[10]);
	createParam(P_mks937bSSCh12String,			asynParamInt32,                  &P_mks937bSS[11]);

	createParam(P_mks937bPROCh1String,			asynParamFloat64,                &P_mks937bPRO[0]);
	createParam(P_mks937bPROCh3String,			asynParamFloat64,                &P_mks937bPRO[1]);
	createParam(P_mks937bPROCh5String,			asynParamFloat64,                &P_mks937bPRO[2]);

	createParam(P_mks937bCSPCh1String,			asynParamFloat64,                &P_mks937bCSP[0]);
	createParam(P_mks937bCSPCh3String,			asynParamFloat64,                &P_mks937bCSP[1]);
	createParam(P_mks937bCSPCh5String,			asynParamFloat64,                &P_mks937bCSP[2]);
	
	createParam(P_mks937bXSPCh1String,			asynParamInt32,                  &P_mks937bXSP[0]);
	createParam(P_mks937bXSPCh3String,			asynParamInt32,                  &P_mks937bXSP[1]);
	createParam(P_mks937bXSPCh5String,			asynParamInt32,                  &P_mks937bXSP[2]);
	
	createParam(P_mks937bCHPCh1String,			asynParamFloat64,                &P_mks937bCHP[0]);
	createParam(P_mks937bCHPCh3String,			asynParamFloat64,                &P_mks937bCHP[1]);
	createParam(P_mks937bCHPCh5String,			asynParamFloat64,                &P_mks937bCHP[2]);
	
	createParam(P_mks937bCSECh1String,			asynParamInt32,                  &P_mks937bCSE[0]);
	createParam(P_mks937bCSECh3String,			asynParamInt32,                  &P_mks937bCSE[1]);
	createParam(P_mks937bCSECh5String,			asynParamInt32,                  &P_mks937bCSE[2]);
	
	createParam(P_mks937bCTLCh1String,			asynParamInt32,                  &P_mks937bCTL[0]);
	createParam(P_mks937bCTLCh3String,			asynParamInt32,                  &P_mks937bCTL[1]);
	createParam(P_mks937bCTLCh5String,			asynParamInt32,                  &P_mks937bCTL[2]);
	
	createParam(P_mks937bUCCh1String,			asynParamFloat64,                &P_mks937bUC[0]);
	createParam(P_mks937bUCCh3String,			asynParamFloat64,                &P_mks937bUC[1]);
	createParam(P_mks937bUCCh5String,			asynParamFloat64,                &P_mks937bUC[2]);
	
	createParam(P_mks937bCPCh1String,			asynParamInt32,                  &P_mks937bCP[0]);
	createParam(P_mks937bCPCh3String,			asynParamInt32,                  &P_mks937bCP[1]);
	createParam(P_mks937bCPCh5String,			asynParamInt32,                  &P_mks937bCP[2]);
	
	createParam(P_mks937bGTCh1String,			asynParamInt32,                  &P_mks937bGT[0]);
	createParam(P_mks937bGTCh3String,			asynParamInt32,                  &P_mks937bGT[1]);
	createParam(P_mks937bGTCh5String,			asynParamInt32,                  &P_mks937bGT[2]);
	
	createParam(P_mks937bTCh1String	,			asynParamInt32,                  &P_mks937bT[0]);
	createParam(P_mks937bTCh3String	,			asynParamInt32,                  &P_mks937bT[1]);
	createParam(P_mks937bTCh5String	,			asynParamInt32,                  &P_mks937bT[2]);
	
	createParam(P_mks937bTDCCh1String,			asynParamInt32,                  &P_mks937bTDC[0]);
	createParam(P_mks937bTDCCh3String,			asynParamInt32,                  &P_mks937bTDC[1]);
	createParam(P_mks937bTDCCh5String,			asynParamInt32,                  &P_mks937bTDC[2]);
	
	createParam(P_mks937bFRCCh1String,			asynParamFloat64,                  &P_mks937bFRC[0]);
	createParam(P_mks937bFRCCh3String,			asynParamFloat64,                  &P_mks937bFRC[1]);
	createParam(P_mks937bFRCCh5String,			asynParamFloat64,                  &P_mks937bFRC[2]);
	
	createParam(P_mks937bUString	,			asynParamInt32,                  &P_mks937bU);
	
	createParam(P_mks937bFeatureRequestString, asynParamInt32,					&P_mks937bFeatureRequest);

	createParam(P_mks937bCommDelayDiagString,	asynParamFloat64,                &P_mks937bCommDelayDiag);
	createParam(P_mks937bCommDelayString	,	asynParamFloat64,                &P_mks937bCommDelay);
	
	setIntegerParam(P_mks937bIsAlive, 0);
	setDoubleParam(P_mks937bCommDelay, m_dbCommDelay);
	setDoubleParam(P_mks937bCommDelayDiag,0);

	status = pasynOctetSyncIO->connect(commPortName,0,&m_pComm,NULL);
	if(status != asynSuccess)
		errlogPrintf("%s:%s error calling pasynOctetSyncIO->connect %s\n",m_pComm->errorMessage);

	//pasynOctetSyncIO->setInputEos(m_pComm,"FF",2);
	pasynOctetSyncIO->setInputEos(m_pComm,";",1);
	pasynOctetSyncIO->setOutputEos(m_pComm,"FF",2);

	// init
	for(int i=0;i!=6;++i)
		m_dbPR[i] = 0;
	for(int i=0;i!=2;++i)
		m_dbPC[i] = 0;
	for(int i=0;i!=12;++i)
	{
		m_dbSP[i]=0;
		m_dbSH[i]=0;
		m_nSD[i]=0;
		m_nEN[i]=0;
		m_nSS[i]=0;
	}
	for(int i=0;i!=3;++i)
	{
		m_dbPRO[i]=0;
		m_dbCSP[i]=0;
		m_nXSP[i]=0;
		m_dbCHP[i]=0;
		m_nCSE[i]=0;
		m_nCTL[i]=0;
		m_dbUC[i]=0;
		m_nCP[i]=0;
		m_nGT[i]=0;
		m_nT[i]=0;
		m_nTDC[i]=0;
		m_dbFRC[i]=0;
	}
	m_nUnit = 0;
	status = getFeatures();
	callParamCallbacks();

	m_bRun = true;
	if(epicsThreadCreate("drvMks937b",
				epicsThreadPriorityHigh,
				epicsThreadGetStackSize(epicsThreadStackMedium),
				(EPICSTHREADFUNC)threadFunc,this) == NULL)
		errlogPrintf("%s:%s Can't create thread...\n",driverName,functionName);

	epicsAtExit(mks937bShutdown,this);
}

void drvMks937b::threadFunc(drvMks937b *pParam)
{
	const char *functionName = "threadFunc";
	drvMks937b *pPvt = (drvMks937b*)pParam;

	epicsTimeStamp beg,end;
	int aliveCheck = 0;

	while(pPvt->m_bRun)
	{
		epicsTimeGetCurrent(&beg);
		aliveCheck = 0;

		for(int i=0;i!=6;++i)
			if(pPvt->getPR(i) != asynSuccess)
				++aliveCheck;
		if(aliveCheck > 0)
			pPvt->setAlive(0);
		else
			pPvt->setAlive(1);
			
		epicsThreadSleep(pPvt->getCommDelay());
		epicsTimeGetCurrent(&end);
		pPvt->setCommDelayDiag(epicsTimeDiffInSeconds(&end,&beg));

		pPvt->updateTimeStamp();
		pPvt->callParamCallbacks();
	}
}

void drvMks937b::setCommDelayDiag(const double tDiff)
{
	setDoubleParam(P_mks937bCommDelayDiag,tDiff);
}

drvMks937b::~drvMks937b()
{
}

void drvMks937b::mks937bShutdown(void *pParam)
{
	const char *functionName = "mks937bShutdown";
	drvMks937b *pPvt = (drvMks937b*)pParam;

	pPvt->m_bRun = false;
	epicsThreadSleep(1);

	errlogPrintf("%s:%s shutdown...\n",driverName,functionName);
}


void drvMks937b::setAlive(const int value)
{
	setIntegerParam(P_mks937bIsAlive,value);
}

double drvMks937b::getCommDelay() const 
{
	return m_dbCommDelay;
}


asynStatus drvMks937b::writeInt32(asynUser *pasynUser, epicsInt32 value)
{
	int function = pasynUser->reason;
	asynStatus status = asynSuccess;
	epicsInt32 rbv;
	const char *paramName;
	const char *functionName = "writeInt32";

	status = setIntegerParam(function,value);

	if(function == P_mks937bFeatureRequest)
		getFeatures();

	if(function == P_mks937bSD[0]){	setSD(0,value); getSD(0);}
	if(function == P_mks937bSD[1]){	setSD(1,value); getSD(1);}
	if(function == P_mks937bSD[2]){	setSD(2,value); getSD(2);}
	if(function == P_mks937bSD[3]){	setSD(3,value); getSD(3);}
	if(function == P_mks937bSD[4]){	setSD(4,value); getSD(4);}
	if(function == P_mks937bSD[5]){	setSD(5,value); getSD(5);}
	if(function == P_mks937bSD[6]){	setSD(6,value); getSD(6);}
	if(function == P_mks937bSD[7]){	setSD(7,value); getSD(7);}
	if(function == P_mks937bSD[8]){	setSD(8,value); getSD(8);}
	if(function == P_mks937bSD[9]){	setSD(9,value); getSD(9);}
	if(function == P_mks937bSD[10]){	setSD(10,value); getSD(10);}
	if(function == P_mks937bSD[11]){	setSD(11,value); getSD(11);}
	
	if(function == P_mks937bEN[0]){	setEN(0,value); getEN(0);}
	if(function == P_mks937bEN[1]){	setEN(1,value); getEN(1);}
	if(function == P_mks937bEN[2]){	setEN(2,value); getEN(2);}
	if(function == P_mks937bEN[3]){	setEN(3,value); getEN(3);}
	if(function == P_mks937bEN[4]){	setEN(4,value); getEN(4);}
	if(function == P_mks937bEN[5]){	setEN(5,value); getEN(5);}
	if(function == P_mks937bEN[6]){	setEN(6,value); getEN(6);}
	if(function == P_mks937bEN[7]){	setEN(7,value); getEN(7);}
	if(function == P_mks937bEN[8]){	setEN(8,value); getEN(8);}
	if(function == P_mks937bEN[9]){	setEN(9,value); getEN(9);}
	if(function == P_mks937bEN[10]){	setEN(10,value); getEN(10);}
	if(function == P_mks937bEN[11]){	setEN(11,value); getEN(11);}
	
	if(function == P_mks937bXSP[0]){	setXSP(0,value); getXSP(0);}
	if(function == P_mks937bXSP[1]){	setXSP(1,value); getXSP(1);}
	if(function == P_mks937bXSP[2]){	setXSP(2,value); getXSP(2);}
	
	if(function == P_mks937bCSE[0]){	setCSE(0,value); getCSE(0);}
	if(function == P_mks937bCSE[1]){	setCSE(1,value); getCSE(1);}
	if(function == P_mks937bCSE[2]){	setCSE(2,value); getCSE(2);}
	
	if(function == P_mks937bCTL[0]){	setCTL(0,value); getCTL(0);}
	if(function == P_mks937bCTL[1]){	setCTL(1,value); getCTL(1);}
	if(function == P_mks937bCTL[2]){	setCTL(2,value); getCTL(2);}
	
	if(function == P_mks937bCP[0]){	setCP(0,value); getCP(0);}
	if(function == P_mks937bCP[1]){	setCP(1,value); getCP(1);}
	if(function == P_mks937bCP[2]){	setCP(2,value); getCP(2);}
	
	if(function == P_mks937bGT[0]){	setGT(0,value); getGT(0);}
	if(function == P_mks937bGT[1]){	setGT(1,value); getGT(1);}
	if(function == P_mks937bGT[2]){	setGT(2,value); getGT(2);}
	
	if(function == P_mks937bTDC[0]){	setTDC(0,value); getTDC(0);}
	if(function == P_mks937bTDC[1]){	setTDC(1,value); getTDC(1);}
	if(function == P_mks937bTDC[2]){	setTDC(2,value); getTDC(2);}
	
	if(function == P_mks937bU)	{setUnit(value); getUnit();}
	
	callParamCallbacks();
}

asynStatus drvMks937b::writeFloat64(asynUser *pasynUser, epicsFloat64 value)
{
	int function = pasynUser->reason;
	asynStatus status = asynSuccess;
	epicsInt32 rbv;
	const char *paramName;
	const char *functionName = "writeFloat32";
	
	status = setDoubleParam(function,value);

	if(function == P_mks937bCommDelay)	m_dbCommDelay = value;
	if(function == P_mks937bSP[0]){	setSP(0,value); getSP(0);}
	if(function == P_mks937bSP[1]){	setSP(1,value); getSP(1);}
	if(function == P_mks937bSP[2]){	setSP(2,value); getSP(2);}
	if(function == P_mks937bSP[3]){	setSP(3,value); getSP(3);}
	if(function == P_mks937bSP[4]){	setSP(4,value); getSP(4);}
	if(function == P_mks937bSP[5]){	setSP(5,value); getSP(5);}
	if(function == P_mks937bSP[6]){	setSP(6,value); getSP(6);}
	if(function == P_mks937bSP[7]){	setSP(7,value); getSP(7);}
	if(function == P_mks937bSP[8]){	setSP(8,value); getSP(8);}
	if(function == P_mks937bSP[9]){	setSP(9,value); getSP(9);}
	if(function == P_mks937bSP[10]){	setSP(10,value); getSP(10);}
	if(function == P_mks937bSP[11]){	setSP(11,value); getSP(11);}

	if(function == P_mks937bSH[0]){	setSH(0,value); getSH(0);}
	if(function == P_mks937bSH[1]){	setSH(1,value); getSH(1);}
	if(function == P_mks937bSH[2]){	setSH(2,value); getSH(2);}
	if(function == P_mks937bSH[3]){	setSH(3,value); getSH(3);}
	if(function == P_mks937bSH[4]){	setSH(4,value); getSH(4);}
	if(function == P_mks937bSH[5]){	setSH(5,value); getSH(5);}
	if(function == P_mks937bSH[6]){	setSH(6,value); getSH(6);}
	if(function == P_mks937bSH[7]){	setSH(7,value); getSH(7);}
	if(function == P_mks937bSH[8]){	setSH(8,value); getSH(8);}
	if(function == P_mks937bSH[9]){	setSH(9,value); getSH(9);}
	if(function == P_mks937bSH[10]){	setSH(10,value); getSH(10);}
	if(function == P_mks937bSH[11]){	setSH(11,value); getSH(11);}
	
	if(function == P_mks937bPRO[0]){	setPRO(0,value); getPRO(0);}
	if(function == P_mks937bPRO[1]){	setPRO(1,value); getPRO(1);}
	if(function == P_mks937bPRO[2]){	setPRO(2,value); getPRO(2);}
	
	if(function == P_mks937bCSP[0]){	setCSP(0,value); getCSP(0);}
	if(function == P_mks937bCSP[1]){	setCSP(1,value); getCSP(1);}
	if(function == P_mks937bCSP[2]){	setCSP(2,value); getCSP(2);}
	
	if(function == P_mks937bUC[0]){	setUC(0,value); getUC(0);}
	if(function == P_mks937bUC[1]){	setUC(1,value); getUC(1);}
	if(function == P_mks937bUC[2]){	setUC(2,value); getUC(2);}
	
	if(function == P_mks937bCHP[0]){	setCHP(0,value); getCHP(0);}
	if(function == P_mks937bCHP[1]){	setCHP(1,value); getCHP(1);}
	if(function == P_mks937bCHP[2]){	setCHP(2,value); getCHP(2);}
	
	if(function == P_mks937bFRC[0]){	setFRC(0,value); getFRC(0);}
	if(function == P_mks937bFRC[1]){	setFRC(1,value); getFRC(1);}
	if(function == P_mks937bFRC[2]){	setFRC(2,value); getFRC(2);}
	
	callParamCallbacks();
}


asynStatus drvMks937b::getFeatures()
{
	asynStatus status = asynSuccess;
	
	for(int i=0;i!=2;++i)
	{
		status = getPC(i);
		if(status != asynSuccess) return status;
	}

	for(int i=0;i!=12;++i)
	{
		status = getSP(i);
		if(status != asynSuccess) return status;

		status = getSH(i);
		if(status != asynSuccess) return status;

		status = getSD(i);
		if(status != asynSuccess) return status;
	
		status = getEN(i);
		if(status != asynSuccess) return status;

		status = getSS(i);
		if(status != asynSuccess) return status;
	}
	
	for(int i=0;i!=3;++i)
	{
		status = getPRO(i);
		if(status != asynSuccess) return status;

		status = getCSP(i);
		if(status != asynSuccess) return status;

		status = getXSP(i);
		if(status != asynSuccess) return status;

		status = getCHP(i);
		if(status != asynSuccess) return status;

		status = getCSE(i);
		if(status != asynSuccess) return status;

		status = getCTL(i);
		if(status != asynSuccess) return status;

		status = getUC(i);
		if(status != asynSuccess) return status;

		status = getCP(i);
		if(status != asynSuccess) return status;

		status = getGT(i);
		if(status != asynSuccess) return status;

		status = getT(i);
		if(status != asynSuccess) return status;

		status = getTDC(i);
		if(status != asynSuccess) return status;

		status = getFRC(i);
		if(status != asynSuccess) return status;
	}

	status = getUnit();
	if(status != asynSuccess) return status;
	
	return status;
}

double drvMks937b::myAtoF(char *buf, size_t len)
{
	char str[32];
	memset(str,0x00,32);
	strncpy(str,buf,len);
	return atof(str);
}

asynStatus drvMks937b::getPR(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dPR%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		epicsPrintf("PR: [%d] is error\n",channel);
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbPR[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bPR[channel],m_dbPR[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::getPC(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dPC%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbPC[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bPC[channel],m_dbPC[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::getSP(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSP%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{	
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbSP[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bSP[channel],m_dbSP[channel]);
		}
	}
	return status;
}

asynStatus drvMks937b::setSP(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSP%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;

	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getSH(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSH%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbSH[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bSH[channel],m_dbSH[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setSH(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSH%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getSD(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSD%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"ABOVE",5) == 0 )
				m_nSD[channel] = sd::above;
			else if(strncmp(&recvBuf[7],"BELOW",5) == 0 )
				m_nSD[channel] = sd::below;

			setIntegerParam(P_mks937bSD[channel],m_nSD[channel]);
		}
	}
	
	return status;
}

asynStatus drvMks937b::setSD(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == sd::above)
		cmd = "ABOVE";
	else if(val == sd::below)
		cmd = "BELOW";
	else return status;

	sprintf(sendBuf,"@%3dSD%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getEN(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dEN%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"SET",3) == 0 )
				m_nEN[channel] = en::set;
			else if(strncmp(&recvBuf[7],"ENABLE",6) == 0 )
				m_nEN[channel] = en::enable;
			else if(strncmp(&recvBuf[7],"CLEAR",5) == 0 )
				m_nEN[channel] = en::clear;
    
			setIntegerParam(P_mks937bEN[channel],m_nEN[channel]);
		}
	}
	return status;
}

asynStatus drvMks937b::setEN(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == en::set)
		cmd = "SET";
	else if(val == en::enable)
		cmd = "ENABLE";
	else if(val == en::clear)
		cmd = "CLEAR";
	else return status;

	sprintf(sendBuf,"@%3dEN%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getSS(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dSS%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"SET",3) == 0 )
				m_nSS[channel] = ss::set;
			else if(strncmp(&recvBuf[7],"CLEAR",5) == 0 )
				m_nSS[channel] = ss::clear;
    
			setIntegerParam(P_mks937bSS[channel],m_nSS[channel]);
		}
	}
	return status;
}

asynStatus drvMks937b::getPRO(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dPRO%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbPRO[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bPRO[channel],m_dbPRO[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setPRO(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dPRO%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getCSP(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCSP%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbCSP[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bCSP[channel],m_dbCSP[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setCSP(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCSP%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getXSP(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dXSP%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"ON",2) == 0 )
				m_nXSP[channel] = xsp::on;
			else if(strncmp(&recvBuf[7],"OFF",3) == 0 )
				m_nXSP[channel] = xsp::off;
    
			setIntegerParam(P_mks937bXSP[channel],m_nXSP[channel]); 
		}
	}
	return status;
}

asynStatus drvMks937b::setXSP(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == xsp::on)
		cmd = "ON";
	else if(val == xsp::off)
		cmd = "OFF";
	else return status;

	sprintf(sendBuf,"@%3dXSP%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getCHP(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCHP%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbCHP[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bCHP[channel],m_dbCHP[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setCHP(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCHP%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getCSE(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCSE%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"A1",2) == 0 )
				m_nCSE[channel] = cse::a1;
			else if(strncmp(&recvBuf[7],"B1",2) == 0 )
				m_nCSE[channel] = cse::b1;
			else if(strncmp(&recvBuf[7],"A2",2) == 0 )
				m_nCSE[channel] = cse::a2;
			else if(strncmp(&recvBuf[7],"B2",2) == 0 )
				m_nCSE[channel] = cse::b2;
			else if(strncmp(&recvBuf[7],"C1",2) == 0 )
				m_nCSE[channel] = cse::c1;
			else if(strncmp(&recvBuf[7],"C2",2) == 0 )
				m_nCSE[channel] = cse::c2;
			else if(strncmp(&recvBuf[7],"OFF",3) == 0 )
				m_nCSE[channel] = cse::off;
        
			 setIntegerParam(P_mks937bCSE[channel],m_nCSE[channel]);
		}
	}
	return status;
}

asynStatus drvMks937b::setCSE(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == cse::a1)
		cmd = "A1";
	else if(val == cse::b1)
		cmd = "B1";
	else if(val == cse::a2)
		cmd = "A2";
	else if(val == cse::b2)
		cmd = "B2";
	else if(val == cse::c1)
		cmd = "C1";
	else if(val == cse::c2)
		cmd = "C2";
	else if(val == cse::off)
		cmd = "OFF";
	else return status;

	sprintf(sendBuf,"@%3dCSE%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getCTL(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCTL%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"AUTO",4) == 0 )
				m_nCTL[channel] = ctl::Auto;
			else if(strncmp(&recvBuf[7],"SAFE",4) == 0 )
				m_nCTL[channel] = ctl::safe;
			else if(strncmp(&recvBuf[7],"OFF",2) == 0 )
				m_nCTL[channel] = ctl::off;
    
			setIntegerParam(P_mks937bCTL[channel],m_nCTL[channel]);
		}
	}
	return status;
}

asynStatus drvMks937b::setCTL(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == ctl::Auto)
		cmd = "AUTO";
	else if(val == ctl::safe)
		cmd = "SAFE";
	else if(val == ctl::off)
		cmd = "OFF";
	else return status;

	sprintf(sendBuf,"@%3dCTL%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getUC(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dUC%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbUC[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bUC[channel],m_dbUC[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setUC(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dUC%1d!%02.1f;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getCP(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dCP%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"ON",2) == 0 )
				m_nCP[channel] = cp::on;
			else if(strncmp(&recvBuf[7],"OFF",3) == 0 )
				m_nCP[channel] = cp::off;
			setIntegerParam(P_mks937bCP[channel],m_nCP[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setCP(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == cp::on)
		cmd = "ON";
	else if(val == cp::off)
		cmd = "OFF";
	else return status;

	sprintf(sendBuf,"@%3dCP%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getGT(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dGT%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"NITROGEN",8) == 0 )
				m_nGT[channel] = gt::nitrogen;
			else if(strncmp(&recvBuf[7],"ARGON",5) == 0 )
				m_nGT[channel] = gt::argon;
			else if(strncmp(&recvBuf[7],"HELIUM",6) == 0 )
				m_nGT[channel] = gt::helium;
			 setIntegerParam(P_mks937bGT[channel],m_nGT[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setGT(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == gt::nitrogen)
		cmd = "NITROGEN";
	else if(val == gt::argon)
		cmd = "ARGON";
	else if(val == gt::helium)
		cmd = "HELIUM";
	else return status;

	sprintf(sendBuf,"@%3dGT%1d!%s;",m_nDevAddr,channel+1,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getT(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dT%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"W",1) == 0 )
				m_nT[channel] = t::w;
			else if(strncmp(&recvBuf[7],"P",1) == 0 )
				m_nT[channel] = t::p;
			else if(strncmp(&recvBuf[7],"O",1) == 0 )
				m_nT[channel] = t::o;
			else if(strncmp(&recvBuf[7],"C",1) == 0 )
				m_nT[channel] = t::c;
			else if(strncmp(&recvBuf[7],"G",1) == 0 )
				m_nT[channel] = t::g;
			else if(strncmp(&recvBuf[7],"R",1) == 0 )
				m_nT[channel] = t::r;
			 setIntegerParam(P_mks937bT[channel],m_nT[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::getTDC(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dTDC%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_nTDC[channel] = myAtoF(&recvBuf[7],3); 
			setIntegerParam(P_mks937bTDC[channel],m_nTDC[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setTDC(const int channel, const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dTDC%1d!%03d;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getFRC(const int channel)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dFRC%1d?;",m_nDevAddr,channel+1);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			m_dbFRC[channel] = myAtoF(&recvBuf[7],8); 
			setDoubleParam(P_mks937bFRC[channel],m_dbFRC[channel]);
		}
	}

	return status;
}

asynStatus drvMks937b::setFRC(const int channel, const double val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dFRC%1d!%.2le;",m_nDevAddr,channel+1,val);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

asynStatus drvMks937b::getUnit()
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;

	sprintf(sendBuf,"@%3dU?;",m_nDevAddr);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	else
	{
		if(strncmp(&recvBuf[4],"NAK",3) != 0)
		{
			if(strncmp(&recvBuf[7],"TORR",4) == 0 )
				m_nUnit = u::torr;
			else if(strncmp(&recvBuf[7],"mBAR",4) == 0 )
				m_nUnit = u::mbar;
			else if(strncmp(&recvBuf[7],"PASCAL",6) == 0 )
				m_nUnit = u::pascal;
			else if(strncmp(&recvBuf[7],"MICRON",6) == 0 )
				m_nUnit = u::micron;
			setIntegerParam(P_mks937bU,m_nUnit);
		}
	}

	return status;
}

asynStatus drvMks937b::setUnit(const int val)
{
	asynStatus status = asynSuccess;
	char recvBuf[32];
	char sendBuf[32];	
	size_t nSendBytes;
	size_t nRecvBytes;
	int eomReason;
	char *cmd;

	if(val == u::torr)
		cmd = "TORR";
	else if(val == u::mbar)
		cmd = "mBAR";
	else if(val == u::pascal)
		cmd = "PASCAL";
	else if(val == u::micron)
		cmd = "MICRON";
	else return status;

	sprintf(sendBuf,"@%3dU!%s;",m_nDevAddr,cmd);

	status = pasynOctetSyncIO->writeRead(m_pComm,
        sendBuf,
        strlen(sendBuf),
        recvBuf,
        32,
        m_dbTimeout,
        &nSendBytes,
        &nRecvBytes,
        &eomReason);

	if(status != asynSuccess)
    	errlogPrintf("SendAndReceive error calling writeRead, output=%s, status=%d, error=%s\n",
            sendBuf,status,m_pComm->errorMessage);

	if(!((strncmp(&recvBuf[4],"ACK",3) == 0) || (strncmp(&recvBuf[4],"NAK",3) == 0)))
		return asynError;
	if(strncmp(&recvBuf[4],"NAK",3) == 0)
		return status;

	return status;
}

////////////////////////////////////////////////////////////////////////////////
//// EPICS FUNC
//////////////////////////////////////////////////////////////////////////////////
extern "C"{
int drvMks937bConfigure(const char *myPortName,const char *commPortName, const int nDevAddr, const double dbTimeout, const int nDevIdx)
{
	drvMks937b *mks937b = new drvMks937b(myPortName,commPortName,nDevAddr, dbTimeout,nDevIdx);
	mks937b = NULL;
	return asynSuccess;
}

static const iocshArg drvMks937bConfigureArg0 = {"myPortName",iocshArgString};
static const iocshArg drvMks937bConfigureArg1 = {"commPortName",iocshArgString};
static const iocshArg drvMks937bConfigureArg2 = {"Device Address",iocshArgInt};
static const iocshArg drvMks937bConfigureArg3 = {"comm timeout",iocshArgDouble};
static const iocshArg drvMks937bConfigureArg4 = {"device index",iocshArgInt};

static const iocshArg * const drvMks937bConfigureArgs[] = {
	&drvMks937bConfigureArg0, 
	&drvMks937bConfigureArg1, 
	&drvMks937bConfigureArg2,
	&drvMks937bConfigureArg3,
	&drvMks937bConfigureArg4};

static const iocshFuncDef drvMks937bConfigureDef = {"drvMks937bConfigure",5,drvMks937bConfigureArgs};

static void drvMks937bConfigureCallFunc(const iocshArgBuf * args)
{
	drvMks937bConfigure(args[0].sval,args[1].sval,args[2].ival,args[3].dval,args[4].ival);
}

void drvMks937bConfigureRegister(void)
{
	iocshRegister(&drvMks937bConfigureDef,drvMks937bConfigureCallFunc);
}

epicsExportRegistrar(drvMks937bConfigureRegister);
} // extern "C"

