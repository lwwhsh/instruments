#ifndef DRVMKS937B_H
#define DRVMKS937B_H
#include <asynPortDriver.h>

#define P_mks937bIsAliveString				"MKS937B_ISALIVE"						/* asynInt32, r, 1:connected 0:disconnected */
#define P_mks937bPRCh1String						"MKS937B_PR_CH1"				/* asynFloat64, r, */
#define P_mks937bPRCh2String						"MKS937B_PR_CH2"				/* asynFloat64, r, */
#define P_mks937bPRCh3String						"MKS937B_PR_CH3"				/* asynFloat64, r, */
#define P_mks937bPRCh4String						"MKS937B_PR_CH4"				/* asynFloat64, r, */
#define P_mks937bPRCh5String						"MKS937B_PR_CH5"				/* asynFloat64, r, */
#define P_mks937bPRCh6String						"MKS937B_PR_CH6"				/* asynFloat64, r, */
#define P_mks937bPCCh1String						"MKS937B_PC_CH1"	/* asynFloat64, r, */
#define P_mks937bPCCh2String						"MKS937B_PC_CH2"	/* asynFloat64, r, */
#define P_mks937bSPCh1String			"MKS937B_SP_CH1"			/* asynFloat64, r/w, */
#define P_mks937bSPCh2String			"MKS937B_SP_CH2"			/* asynFloat64, r/w, */
#define P_mks937bSPCh3String			"MKS937B_SP_CH3"			/* asynFloat64, r/w, */
#define P_mks937bSPCh4String			"MKS937B_SP_CH4"			/* asynFloat64, r/w, */
#define P_mks937bSPCh5String			"MKS937B_SP_CH5"			/* asynFloat64, r/w, */
#define P_mks937bSPCh6String			"MKS937B_SP_CH6"			/* asynFloat64, r/w, */
#define P_mks937bSPCh7String			"MKS937B_SP_CH7"			/* asynFloat64, r/w, */
#define P_mks937bSPCh8String			"MKS937B_SP_CH8"			/* asynFloat64, r/w, */
#define P_mks937bSPCh9String			"MKS937B_SP_CH9"			/* asynFloat64, r/w, */
#define P_mks937bSPCh10String			"MKS937B_SP_CH10"			/* asynFloat64, r/w, */
#define P_mks937bSPCh11String			"MKS937B_SP_CH11"			/* asynFloat64, r/w, */
#define P_mks937bSPCh12String			"MKS937B_SP_CH12"			/* asynFloat64, r/w, */
#define P_mks937bSHCh1String			"MKS937B_SH_CH1"			/* asynFloat64, r/w, */
#define P_mks937bSHCh2String			"MKS937B_SH_CH2"			/* asynFloat64, r/w, */
#define P_mks937bSHCh3String			"MKS937B_SH_CH3"			/* asynFloat64, r/w, */
#define P_mks937bSHCh4String			"MKS937B_SH_CH4"			/* asynFloat64, r/w, */
#define P_mks937bSHCh5String			"MKS937B_SH_CH5"			/* asynFloat64, r/w, */
#define P_mks937bSHCh6String			"MKS937B_SH_CH6"			/* asynFloat64, r/w, */
#define P_mks937bSHCh7String			"MKS937B_SH_CH7"			/* asynFloat64, r/w, */
#define P_mks937bSHCh8String			"MKS937B_SH_CH8"			/* asynFloat64, r/w, */
#define P_mks937bSHCh9String			"MKS937B_SH_CH9"			/* asynFloat64, r/w, */
#define P_mks937bSHCh10String			"MKS937B_SH_CH10"			/* asynFloat64, r/w, */
#define P_mks937bSHCh11String			"MKS937B_SH_CH11"			/* asynFloat64, r/w, */
#define P_mks937bSHCh12String			"MKS937B_SH_CH12"			/* asynFloat64, r/w, */
#define P_mks937bSDCh1String			"MKS937B_SD_CH1"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh2String			"MKS937B_SD_CH2"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh3String			"MKS937B_SD_CH3"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh4String			"MKS937B_SD_CH4"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh5String			"MKS937B_SD_CH5"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh6String			"MKS937B_SD_CH6"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh7String			"MKS937B_SD_CH7"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh8String			"MKS937B_SD_CH8"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh9String			"MKS937B_SD_CH9"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh10String			"MKS937B_SD_CH10"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh11String			"MKS937B_SD_CH11"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bSDCh12String			"MKS937B_SD_CH12"			/* asynInt32, r/w, ABOVE or BELOW or NAK162(BELOW)*/
#define P_mks937bENCh1String			"MKS937B_EN_CH1"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh2String			"MKS937B_EN_CH2"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh3String			"MKS937B_EN_CH3"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh4String			"MKS937B_EN_CH4"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh5String			"MKS937B_EN_CH5"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh6String			"MKS937B_EN_CH6"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh7String			"MKS937B_EN_CH7"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh8String			"MKS937B_EN_CH8"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh9String			"MKS937B_EN_CH9"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh10String			"MKS937B_EN_CH10"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh11String			"MKS937B_EN_CH11"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bENCh12String			"MKS937B_EN_CH12"				/* asynInt32, r/w, SET, ENABLE, CLEAR */
#define P_mks937bSSCh1String		"MKS937B_SS_CH1"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh2String		"MKS937B_SS_CH2"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh3String		"MKS937B_SS_CH3"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh4String		"MKS937B_SS_CH4"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh5String		"MKS937B_SS_CH5"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh6String		"MKS937B_SS_CH6"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh7String		"MKS937B_SS_CH7"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh8String		"MKS937B_SS_CH8"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh9String		"MKS937B_SS_CH9"		/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh10String		"MKS937B_SS_CH10"	/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh11String		"MKS937B_SS_CH11"	/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bSSCh12String		"MKS937B_SS_CH12"	/* asynInt32, r, SET(activated), CLEAR(disabled) */
#define P_mks937bPROCh1String		"MKS937B_PRO_CH1"		/* asynFloat64, r/w, */
#define P_mks937bPROCh3String		"MKS937B_PRO_CH3"		/* asynFloat64, r/w, */
#define P_mks937bPROCh5String		"MKS937B_PRO_CH5"		/* asynFloat64, r/w, */
#define P_mks937bCSPCh1String			"MKS937B_CSP_CH1"		/* asynFloat64, r/w, */
#define P_mks937bCSPCh3String			"MKS937B_CSP_CH3"		/* asynFloat64, r/w, */
#define P_mks937bCSPCh5String			"MKS937B_CSP_CH5"		/* asynFloat64, r/w, */
#define P_mks937bXSPCh1String			"MKS937B_XSP_CH1"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bXSPCh3String			"MKS937B_XSP_CH3"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bXSPCh5String			"MKS937B_XSP_CH5"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bCHPCh1String			"MKS937B_CHP_CH1"		/* asynFloat64, r/w, */
#define P_mks937bCHPCh3String			"MKS937B_CHP_CH3"		/* asynFloat64, r/w, */
#define P_mks937bCHPCh5String			"MKS937B_CHP_CH5"		/* asynFloat64, r/w, */
#define P_mks937bCSECh1String			"MKS937B_CSE_CH1"		/* asynInt32, r/w, A1, B1, A2, B2, C1, C2, OFF*/
#define P_mks937bCSECh3String			"MKS937B_CSE_CH3"		/* asynInt32, r/w, A1, B1, A2, B2, C1, C2, OFF*/
#define P_mks937bCSECh5String			"MKS937B_CSE_CH5"		/* asynInt32, r/w, A1, B1, A2, B2, C1, C2, OFF*/
#define P_mks937bCTLCh1String			"MKS937B_CTL_CH1"		/* asynInt32, r/w, AUTO, SAFE, OFF */
#define P_mks937bCTLCh3String			"MKS937B_CTL_CH3"		/* asynInt32, r/w, AUTO, SAFE, OFF */
#define P_mks937bCTLCh5String			"MKS937B_CTL_CH5"		/* asynInt32, r/w, AUTO, SAFE, OFF */
#define P_mks937bUCCh1String			"MKS937B_UC_CH1"		/* asynFloat64, r/w, */
#define P_mks937bUCCh3String			"MKS937B_UC_CH3"		/* asynFloat64, r/w, */
#define P_mks937bUCCh5String			"MKS937B_UC_CH5"		/* asynFloat64, r/w, */
#define P_mks937bCPCh1String			"MKS937B_CP_CH1"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bCPCh3String			"MKS937B_CP_CH3"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bCPCh5String			"MKS937B_CP_CH5"		/* asynInt32, r/w, ON or OFF */
#define P_mks937bGTCh1String			"MKS937B_GT_CH1"		/* asynInt32, r/w, Nitrogen, Argon, Helium */
#define P_mks937bGTCh3String			"MKS937B_GT_CH3"		/* asynInt32, r/w, Nitrogen, Argon, Helium */
#define P_mks937bGTCh5String			"MKS937B_GT_CH5"		/* asynInt32, r/w, Nitrogen, Argon, Helium */
#define P_mks937bTCh1String			"MKS937B_T_CH1"		/* asynInt32, r, W(wait), P(Protect), O(Off), C(Control), G(Good), R(Rear panel ctrl off) */
#define P_mks937bTCh3String			"MKS937B_T_CH3"		/* asynInt32, r, W(wait), P(Protect), O(Off), C(Control), G(Good), R(Rear panel ctrl off) */
#define P_mks937bTCh5String			"MKS937B_T_CH5"		/* asynInt32, r, W(wait), P(Protect), O(Off), C(Control), G(Good), R(Rear panel ctrl off) */
#define P_mks937bTDCCh1String			"MKS937B_TDC_CH1"		/* asynInt32, r/w, */
#define P_mks937bTDCCh3String			"MKS937B_TDC_CH3"		/* asynInt32, r/w, */
#define P_mks937bTDCCh5String			"MKS937B_TDC_CH5"		/* asynInt32, r/w, */
#define P_mks937bFRCCh1String			"MKS937B_FRC_CH1"		/* asynFloat64, r/w, */
#define P_mks937bFRCCh3String			"MKS937B_FRC_CH3"		/* asynFloat64, r/w, */
#define P_mks937bFRCCh5String			"MKS937B_FRC_CH5"		/* asynFloat64, r/w, */
#define P_mks937bUString			"MKS937B_UNIT"				/* asynInt32, r/w, Torr, MBAR, PASCAL, Micron*/
#define P_mks937bFeatureRequestString	"MKS937B_FEATURE_REQ"				/* asynInt32, r/w, Torr, MBAR, PASCAL, Micron*/
#define P_mks937bCommDelayDiagString		"MKS937B_COMM_DELAY_DIAG"				/* asynFloat64, r, */	
#define P_mks937bCommDelayString			"MKS937B_COMM_DELAY"					/* asynFloat64, r/w, unit: second */

namespace sd
{
	int above = 1;
	int below = 2;
}

namespace en
{
	int set = 1;
	int enable = 2;
	int clear = 3;
}

namespace ss
{
	int set = 1;
	int clear = 2;
}

namespace xsp
{
	int on = 1;
	int off = 2;
}

namespace cse
{
	int a1 = 1;
	int b1 = 2;
	int a2 = 3;
	int b2 = 4;
	int c1 = 5;
	int c2 = 6;
	int off = 7;
}

namespace ctl
{
	int Auto = 1;
	int safe = 2;
	int off = 3;
}

namespace cp
{
	int on = 1;
	int off = 2;
}

namespace gt
{
	int nitrogen = 1;
	int argon = 2;
	int helium = 3;
}

namespace t
{
	int w = 1;
	int p = 2;
	int o = 3;
	int c = 4;
	int g = 5;
	int r = 6;
}

namespace u
{
	int torr = 1;
	int mbar = 2;
	int pascal = 3;
	int micron = 4;
}

class drvMks937b : public asynPortDriver
{
	public:
		drvMks937b(const char *portName, const char *commPortName, const int nDevAddr, const double dbTimeout, const int nDevIdx);
		~drvMks937b();

		virtual asynStatus writeInt32(asynUser *pasynUser, epicsInt32 value);
		virtual asynStatus writeFloat64(asynUser *pasynUser, epicsFloat64 value);

		double getCommDelay() const;
		void setAlive(const int value);
		void setCommDelayDiag(const double tDiff);
		asynStatus getFeatures();

	protected:
		int P_mks937bIsAlive;
#define FIRST_MKS937B_PARAM P_mks937bIsAlive
		int P_mks937bPR[6];
		int P_mks937bPC[2];
		int P_mks937bSP[12];
		int P_mks937bSH[12];
		int P_mks937bSD[12];
		int P_mks937bEN[12];
		int P_mks937bSS[12];
		int P_mks937bPRO[3];
		int P_mks937bCSP[3];
		int P_mks937bXSP[3];
		int P_mks937bCHP[3];
		int P_mks937bCSE[3];
		int P_mks937bCTL[3];
		int P_mks937bUC[3];
		int P_mks937bCP[3];
		int P_mks937bGT[3];
		int P_mks937bT[3];
		int P_mks937bTDC[3];
		int P_mks937bFRC[3];
		int P_mks937bU;		
		int P_mks937bFeatureRequest;
		int P_mks937bCommDelayDiag;
		int P_mks937bCommDelay;	   
#define LAST_MKS937B_PARAM P_mks937bCommDelay
#define NUM_MKS937B_PARAMS (&LAST_MKS937B_PARAM - &FIRST_MKS937B_PARAM + 1)

	public:
		bool m_bRun;
	private:
		int m_nDevIdx;
		double m_dbCommDelay;
		double m_dbTimeout;
		asynUser *m_pComm;

		int m_nDevAddr;
		
		static void threadFunc(drvMks937b *pParam);
		static void mks937bShutdown(void *pParam);

		double myAtoF(char *buf, size_t len);

		// comm.
		
		double m_dbPR[6];
		double m_dbPC[2];
		double m_dbSP[12];
		double m_dbSH[12];
		int m_nSD[12];
		int m_nEN[12];
		int m_nSS[12];
		double m_dbPRO[3];
		double m_dbCSP[3];
		int m_nXSP[3];
		double m_dbCHP[3];
		int m_nCSE[3];
		int m_nCTL[3];
		double m_dbUC[3];
		int m_nCP[3];
		int m_nGT[3];
		int m_nT[3];
		int m_nTDC[3];
		double m_dbFRC[3];
		int m_nUnit;

		asynStatus getPR(const int channel);
		asynStatus getPC(const int channel);
		asynStatus getSP(const int channel);
		asynStatus setSP(const int channel, const double val);
		asynStatus getSH(const int channel);
		asynStatus setSH(const int channel, const double val);
		asynStatus getSD(const int channel);
		asynStatus setSD(const int channel, const int val);
		asynStatus getEN(const int channel);
		asynStatus setEN(const int channel, const int val);
		asynStatus getSS(const int channel);
		asynStatus getPRO(const int channel);
		asynStatus setPRO(const int channel, const double val);
		asynStatus getCSP(const int channel);
		asynStatus setCSP(const int channel, const double val);
		asynStatus getXSP(const int channel);
		asynStatus setXSP(const int channel, const int val);
		asynStatus getCHP(const int channel);
		asynStatus setCHP(const int channel, const double val);
		asynStatus getCSE(const int channel);
		asynStatus setCSE(const int channel, const int val);
		asynStatus getCTL(const int channel);
		asynStatus setCTL(const int channel, const int val);
		asynStatus getUC(const int channel);
		asynStatus setUC(const int channel, const double val);
		asynStatus getCP(const int channel);
		asynStatus setCP(const int channel, const int val);
		asynStatus getGT(const int channel);
		asynStatus setGT(const int channel, const int val);
		asynStatus getT(const int channel);
		asynStatus getTDC(const int channel);
		asynStatus setTDC(const int channel, const int val);
		asynStatus getFRC(const int channel);
		asynStatus setFRC(const int channel, const double val);
		asynStatus getUnit();
		asynStatus setUnit(const int val);
};

#endif
